#' @import Rcpp
#' @import RcppProgress
#' @import RcppArmadillo
#' @useDynLib macro.pfsi
NULL