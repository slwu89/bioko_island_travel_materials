################################################################################
#       __  ______   __________  ____
#      /  |/  /   | / ____/ __ \/ __ \
#     / /|_/ / /| |/ /   / /_/ / / / /
#    / /  / / ___ / /___/ _, _/ /_/ /
#   /_/  /_/_/  |_\____/_/ |_|\____/
#
#   Human-PfSI initialization parameters for constructor
#
#   Sean Wu (slwu89@berkeley.edu)
#   December 2018
#
################################################################################


################################################################################
#   Human constructor
################################################################################

#' Human-PfSI: Individual Constructor Parameters
#'
#' Generates a single named list with parameters to construct a single
#' 'human_pfsi' object (see inst/include/Human-PfSI.hpp for constructor parameters).
#' Be aware that all 'id' related fields should be 0-indexed (especially the home patch).
#'
#' @param id integer id of this person
#' @param home_patch_id the id of their home patch
#' @param trip_duration numeric value; average durarion of trips away from home
#' @param trip_frequency numeric value; average rate at which they make trips away from home
#' @param bweight numeric value; biting weight to this person (relative to others in a patch; should have mean 1)
#' @param age numeric age (not currently used)
#' @param state initial state (must be character in 'S': susceptible, 'I': infected/infectious, 'P': chemoprophylaxis)
#' @param bite_algorithm 0 for poisson, 1 for negative binomial
#' @param bite_disp overdispersion parameter for negative binomial biting (NULL for Poisson)
#'
#' @export
human_pfsi_conpars <- function(id,home_patch_id,trip_duration,trip_frequency,bweight,age,state,bite_algorithm,bite_disp=NaN){
  if(bite_algorithm==1 && (is.null(bite_disp) || is.nan(bite_disp) || is.na(bite_disp))){
    stop("if using negative binomial biting, please provide a valid numeric value for 'bite_disp'")
  }
  if(!(bite_algorithm %in% c(0,1))){
    stop("please use 0 for Poisson distributed biting and 1 for Negative Binomial distributed biting")
  }
  if(!(state %in% c("S","I","P"))){
    stop(paste0("human: ",id," needs an initial state in ('S','I','P')\n"))
  }
  if(any(c(trip_duration,trip_frequency,bweight,age) < 0) | any(!is.numeric(c(trip_duration,trip_frequency,bweight,age)))){
    stop(paste0("human: ",id," 'trip_duration', 'trip_frequency', 'bweight', 'age' must all be positive floating point values\n"))
  }
  list(
    id = as.integer(id),
    home_patch_id = as.integer(home_patch_id),
    trip_duration = as.numeric(trip_duration),
    trip_frequency = as.numeric(trip_frequency),
    bweight = as.numeric(bweight),
    age = as.numeric(age),
    state = as.character(state),
    bite_algorithm = as.integer(bite_algorithm),
    bite_disp = as.numeric(bite_disp)
  )
}


################################################################################
#   PfSI vaccination events
################################################################################

#' Human-PfSI: Make parameters for a vaccination event
#'
#' Make a parameter list for a PE (sporozoite-blocking) vaccination event or GS (gametocyte-killing) vaccination event.
#' The entire parameters list for the population will be a list of size equal
#' to the number of people to recieve vaccination, each element of which is the output
#' of this function.
#'
#' @param id an integer id of a human to recieve vaccination
#' @param t a numeric vector giving times of vaccination events
#' @param treat a logical vector indicating if treatment is to accompany vaccinations
#' @param type "PE" (sporozoite-blocking) or "GS" (gametocyte-killing)
#'
#' @export
vaccination_pfsi_conpars <- function(id,t,treat,type){

  if(!is.numeric(t) | t < 0){
    stop("time of pevaxx event must be a vector of positive floats")
  }

  if(!is.logical(treat)){
    stop("treatment must be a logical vector")
  }

  if(id < 0){
    stop("id must be a positive integer value")
  }

  if(!(type %in% c("PE","GS"))){
    stop("vaccine 'type' must be PE (sporozoite-blocking) or GS (gametocyte-killing)")
  }

  list(
    id = as.integer(id),
    tEvent = as.numeric(t),
    treat = as.logical(treat),
    type = as.character(type)
  )
}
